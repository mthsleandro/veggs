//burger

let burgerChange = document.querySelector("img#burgerChange");
function changeBurger() {
  burgerChange.src = "../imagens/fazenda1.png";
}
function changetxtBurger() {
  document.getElementById("burgername").innerHTML = "Burger Vegetal 2030";
}

function changeBurger2() {
  burgerChange.src = "../imagens/fazenda5.png";
}
function changetxtBurger2() {
  document.getElementById("burgername").innerHTML = "Burger Vegetal Defumado";
}

//soy

let soyChange = document.querySelector("#p4 img#soyChange");
function changeSoy() {
  soyChange.src = "../imagens/produto2.png";
}
function changetxtSoy() {
  document.getElementById("soyname").innerHTML = "Soy Protein Cacau";
}
function changePriceSoy() {
  document.getElementById("soyprice").innerHTML = "R$ 89,90";
}

function changeSoy2() {
  soyChange.src = "../imagens/produto2_2.png";
}
function changetxtSoy2() {
  document.getElementById("soyname").innerHTML = "Soy Protein Baunilha";
}
function changePriceSoy2() {
  document.getElementById("soyprice").innerHTML = "R$ 89,90";
}

function changeSoy3() {
  soyChange.src = "../imagens/produto2_3.png";
}
function changetxtSoy3() {
  document.getElementById("soyname").innerHTML = "Soy Protein Coco";
}
function changePriceSoy3() {
  document.getElementById("soyprice").innerHTML = "R$ 90,99";
}

function changeSoy4() {
  soyChange.src = "../imagens/produto2_4.png";
}
function changetxtSoy4() {
  document.getElementById("soyname").innerHTML = "Soy Protein Paçoca";
}
function changePriceSoy4() {
  document.getElementById("soyprice").innerHTML = "R$ 89,50";
}

function changeSoy4() {
  soyChange.src = "../imagens/produto2_4.png";
}
function changetxtSoy4() {
  document.getElementById("soyname").innerHTML = "Soy Protein Paçoca";
}

//iogurte grego

let gregoChange = document.querySelector("#p6 img#gregoChange");
function changeGrego() {
  gregoChange.src = "../imagens/produto3.png";
}
function changetxtGrego() {
  document.getElementById("gregoname").innerHTML = "Iogurte Grego Tradicional";
}

function changeGrego2() {
  gregoChange.src = "../imagens/produto3_2.png";
}
function changetxtGrego2() {
  document.getElementById("gregoname").innerHTML = "Iogurte Grego Morango";
}

//sorvete

let sorveteChange = document.querySelector("#p12 img#sorveteChange");
function changeSorvete() {
  sorveteChange.src = "../imagens/produto6.png";
}
function changetxtSorvete() {
  document.getElementById("sorvetename").innerHTML = "Sorvete Chocomenta";
}
function changePriceSorvete() {
  document.getElementById("sorveteprice").innerHTML = "R$ 38,80";
}

function changeSorvete2() {
  sorveteChange.src = "../imagens/produto6_2.png";
}
function changetxtSorvete2() {
  document.getElementById("sorvetename").innerHTML = "Sorvete Banoffee";
}
function changePriceSoy2() {
  document.getElementById("sorveteprice").innerHTML = "R$ 37,80";
}

function changeSorvete3() {
  sorveteChange.src = "../imagens/produto6_3.png";
}
function changetxtSorvete3() {
  document.getElementById("sorvetename").innerHTML = "Sorvete Baunilha";
}
function changePriceSorvete3() {
  document.getElementById("sorveteprice").innerHTML = "R$ 38,90";
}

function changeSorvete4() {
  sorveteChange.src = "../imagens/produto6_4.png";
}
function changetxtSorvete4() {
  document.getElementById("sorvetename").innerHTML = "Sorvete Flocos";
}
function changePriceSorvete4() {
  document.getElementById("sorveteprice").innerHTML = "R$ 39,50";
}

function changeSorvete5() {
  sorveteChange.src = "../imagens/produto6_5.png";
}
function changetxtSorvete5() {
  document.getElementById("sorvetename").innerHTML = "Sorvete Morango";
}
function changePriceSorvete5() {
  document.getElementById("sorveteprice").innerHTML = "R$ 38,99";
}

//vovo floria biscoitos

let vovoChange = document.querySelector("#p14 img#vovoChange");
function changeVovo() {
  vovoChange.src = "../imagens/produto7.png";
}
function changetxtVovo() {
  document.getElementById("vovoname").innerHTML = "Biscoito Flocos";
}

function changeVovo2() {
  vovoChange.src = "../imagens/produto7_2.png";
}
function changetxtVovo2() {
  document.getElementById("vovoname").innerHTML = "Biscoito Chocolate";
}

//shake

let shakeChange = document.querySelector("#b3 img#shakeChange");
function changeShake() {
  shakeChange.src = "../imagens/drink3.png";
}
function changetxtShake() {
  document.getElementById("shakename").innerHTML = "Shake de Coco Baunilha";
}
function changepriceShake() {
  document.getElementById("shakeprice").innerHTML = "R$ 6,90";
}

function changeShake2() {
  shakeChange.src = "../imagens/drink3_2.png";
}
function changetxtShake2() {
  document.getElementById("shakename").innerHTML = "Shake de Coco Chocolate";
}
function changepriceShake2() {
  document.getElementById("shakeprice").innerHTML = "R$ 7,20";
}

function changeShake3() {
  shakeChange.src = "../imagens/drink3_3.png";
}
function changetxtShake3() {
  document.getElementById("shakename").innerHTML = "Shake de Coco Morango";
}
function changepriceShake3() {
  document.getElementById("shakeprice").innerHTML = "R$ 6,90";
}

//cafe

let cafeChange = document.querySelector("#b4 img#cafeChange");
function changeCafe() {
  cafeChange.src = "../imagens/drink4.png";
}
function changetxtCafe() {
  document.getElementById("cafename").innerHTML = "Café Latte Vegan";
}
function changepriceCafe() {
  document.getElementById("cafeprice").innerHTML = "R$ 5,50";
}

function changeCafe2() {
  cafeChange.src = "../imagens/drink4_2.png";
}
function changetxtCafe2() {
  document.getElementById("cafename").innerHTML = "Café Cappuccino Vegan";
}
function changepriceCafe2() {
  document.getElementById("cafeprice").innerHTML = "R$ 5,80";
}

//wewi

let wewiChange = document.querySelector("#b5 img#wewiChange");
function changeWewi() {
  wewiChange.src = "../imagens/drink5.png";
}
function changetxtWewi() {
  document.getElementById("wewiname").innerHTML = "Refrigerante Cola";
}

function changeWewi2() {
  wewiChange.src = "../imagens/drink5_2.png";
}
function changetxtWewi2() {
  document.getElementById("wewiname").innerHTML = "Refrigerante Laranja";
}

function changeWewi3() {
  wewiChange.src = "../imagens/drink5_3.png";
}
function changetxtWewi3() {
  document.getElementById("wewiname").innerHTML = "Refrigerante Guaraná";
}

function changeWewi4() {
  wewiChange.src = "../imagens/drink5_4.png";
}
function changetxtWewi4() {
  document.getElementById("wewiname").innerHTML = "Refrigerante Guaraná Zero";
}

//pressade
let pressadeChange = document.querySelector("#b6 img#pressadeChange");
function changePressade() {
  pressadeChange.src = "../imagens/drink6.png";
}
function changetxtPressade() {
  document.getElementById("pressadename").innerHTML = "Suco Orgânico Limão";
}

function changePressade2() {
  pressadeChange.src = "../imagens/drink6_2.png";
}
function changetxtPressade2() {
  document.getElementById("pressadename").innerHTML = "Suco Orgânico Tangerina";
}

function changePressade3() {
  pressadeChange.src = "../imagens/drink6_3.png";
}
function changetxtPressade3() {
  document.getElementById("pressadename").innerHTML = "Suco Orgânico Manga";
}

function changePressade4() {
  pressadeChange.src = "../imagens/drink6_4.png";
}
function changetxtPressade4() {
  document.getElementById("pressadename").innerHTML = "Suco Orgânico Caju";
}

//cafe 3 corações

let cafe3Change = document.querySelector("#b7 img#cafe3Change");
function changeCafe3() {
  cafe3Change.src = "../imagens/drink7.png";
}
function changetxtCafe3() {
  document.getElementById("cafe3name").innerHTML = "Café Orgânico";
}
function changePriceCafe3() {
  document.getElementById("cafe3price").innerHTML = "R$ 16,90";
}

function changeCafe32() {
  cafe3Change.src = "../imagens/drink7_2.png";
}
function changetxtCafe32() {
  document.getElementById("cafe3name").innerHTML = "Café Cerrado Mineiro";
}
function changePriceCafe32() {
  document.getElementById("cafe3price").innerHTML = "R$ 17,80";
}

function changeCafe33() {
  cafe3Change.src = "../imagens/drink7_3.png";
}
function changetxtCafe33() {
  document.getElementById("cafe3name").innerHTML = "Café Mogiana Paulista";
}
function changePriceCafe33() {
  document.getElementById("cafe3price").innerHTML = "R$ 16,90";
}

function changeCafe34() {
  cafe3Change.src = "../imagens/drink7_4.png";
}
function changetxtCafe34() {
  document.getElementById("cafe3name").innerHTML = "Café Sul de Minas";
}
function changePriceCafe34() {
  document.getElementById("cafe3price").innerHTML = "R$ 17,90";
}

//ades

let adesChange = document.querySelector("#b8 img#adesChange");
function changeAdes() {
  adesChange.src = "../imagens/drink8.png";
}
function changetxtAdes() {
  document.getElementById("adesname").innerHTML = "Leite de Soja";
}
function changePriceAdes() {
  document.getElementById("adesprice").innerHTML = "R$ 6,99";
}

function changeAdes2() {
  adesChange.src = "../imagens/drink8_2.png";
}
function changetxtAdes2() {
  document.getElementById("adesname").innerHTML = "Leite de Soja Morango";
}
function changePriceAdes2() {
  document.getElementById("adesprice").innerHTML = "R$ 7,50";
}

function changeAdes3() {
  adesChange.src = "../imagens/drink8_3.png";
}
function changetxtAdes3() {
  document.getElementById("adesname").innerHTML = "Leite de Soja Zero";
}
function changePriceAdes3() {
  document.getElementById("adesprice").innerHTML = "R$ 6,99";
}

function changeAdes4() {
  adesChange.src = "../imagens/drink8_4.png";
}
function changetxtAdes4() {
  document.getElementById("adesname").innerHTML = "Leite de Soja Laranja";
}
function changePriceAdes4() {
  document.getElementById("adesprice").innerHTML = "R$ 6,89";
}

function changeAdes5() {
  adesChange.src = "../imagens/drink8_5.png";
}
function changetxtAdes5() {
  document.getElementById("adesname").innerHTML = "Leite de Soja Amêndoa";
}
function changePriceAdes5() {
  document.getElementById("adesprice").innerHTML = "R$ 7,90";
}

function changeAdes6() {
  adesChange.src = "../imagens/drink8_6.png";
}
function changetxtAdes6() {
  document.getElementById("adesname").innerHTML = "Leite de Soja Coco";
}
function changePriceAdes6() {
  document.getElementById("adesprice").innerHTML = "R$ 6,99";
}

function changeAdes7() {
  adesChange.src = "../imagens/drink8_7.png";
}
function changetxtAdes7() {
  document.getElementById("adesname").innerHTML = "Leite de Soja Maçã";
}
function changePriceAdes7() {
  document.getElementById("adesprice").innerHTML = "INDISPONÍVEL";
}

//adobe vinho

let adobeChange = document.querySelector("#v2 img#adobeChange");
function changeAdobe() {
  adobeChange.src = "../imagens/vinho2.png";
}
function changetxtAdobe() {
  document.getElementById("adobename").innerHTML = "Vinho Tinto Suave";
}
function changepriceAdobe() {
  document.getElementById("adobeprice").innerHTML = "R$ 74,90";
}
function changelabelAdobe() {
  document.getElementById("adobelabel").innerHTML = "CABERNET | Adobe - 750ml";
}
function changetagAdobe() {
  document.getElementById("adobetag").innerHTML = "14,5% ABV";
}
function changetag2Adobe() {
  document.getElementById("adobetag2").innerHTML = "";
}

function changeStyle() {
  var x = document.getElementById("changetag2Adobe");
  if (x.style.display === "none") {
    x.style.display = "none";
  } else {
    x.style.display = "none";
  }
}

function changeAdobe2() {
  adobeChange.src = "../imagens/vinho2_2.png";
}
function changetxtAdobe2() {
  document.getElementById("adobename").innerHTML = "Vinho Tinto Seco";
}
function changepriceAdobe2() {
  document.getElementById("adobeprice").innerHTML = "R$ 82,90";
}
function changelabelAdobe2() {
  document.getElementById("adobelabel").innerHTML = "CARMÉNÈRE | Adobe - 750ml";
}
function changetagAdobe2() {
  document.getElementById("adobetag").innerHTML = "13,5% ABV";
}
function changetag2Adobe2() {
  document.getElementById("adobetag2").innerHTML = "";
}

function changeStyle2() {
  var x = document.getElementById("changetag2Adobe");
  if (x.style.display === "none") {
    x.style.display = "none";
  } else {
    x.style.display = "none";
  }
}

function changeAdobe3() {
  adobeChange.src = "../imagens/vinho2_3.png";
}
function changetxtAdobe3() {
  document.getElementById("adobename").innerHTML = "Vinho Rosé Reserva";
}
function changepriceAdobe3() {
  document.getElementById("adobeprice").innerHTML = "R$ 66,80";
}
function changelabelAdobe3() {
  document.getElementById("adobelabel").innerHTML = "SYRAH | Adobe - 750ml";
}
function changetagAdobe3() {
  document.getElementById("adobetag").innerHTML = "12% ABV";
}
function changetag2Adobe3() {
  document.getElementById("adobetag2").innerHTML = "15% OFF";
}

function changeStyle3() {
  var x = document.getElementById("changetag2Adobe");
  if (x.style.display === "none") {
    x.style.display = "block";
  }
}
function changeAdobe4() {
  adobeChange.src = "../imagens/vinho2_4.png";
}
function changetxtAdobe4() {
  document.getElementById("adobename").innerHTML = "Vinho Branco Reserva";
}
function changepriceAdobe4() {
  document.getElementById("adobeprice").innerHTML = "R$ 89,90";
}
function changelabelAdobe4() {
  document.getElementById("adobelabel").innerHTML =
    "CHARDONNAY | Adobe - 750ml";
}
function changetagAdobe4() {
  document.getElementById("adobetag").innerHTML = "13,5% ABV";
}
function changetag2Adobe4() {
  document.getElementById("adobetag2").innerHTML = "";
}

function changeStyle4() {
  var x = document.getElementById("changetag2Adobe");
  if (x.style.display === "none") {
    x.style.display = "none";
  } else {
    x.style.display = "none";
  }
}

function changeAdobe5() {
  adobeChange.src = "../imagens/vinho2_5.png";
}
function changetxtAdobe5() {
  document.getElementById("adobename").innerHTML = "Vinho Tinto Reserva";
}
function changepriceAdobe5() {
  document.getElementById("adobeprice").innerHTML = "R$ 89,90";
}
function changelabelAdobe5() {
  document.getElementById("adobelabel").innerHTML =
    "PINOT NOIR | Adobe - 750ml";
}
function changetagAdobe5() {
  document.getElementById("adobetag").innerHTML = "13,5% ABV";
}
function changetag2Adobe5() {
  document.getElementById("adobetag2").innerHTML = "";
}

function changeStyle5() {
  var x = document.getElementById("changetag2Adobe");
  if (x.style.display === "none") {
    x.style.display = "none";
  } else {
    x.style.display = "none";
  }
}

//cezaro vinho
let cezaroChange = document.querySelector("#v3 img#cezaroChange");
function changeCezaro() {
  cezaroChange.src = "../imagens/vinho3.png";
}
function changetxtCezaro() {
  document.getElementById("cezaroname").innerHTML = "Vinho Tinto Suave";
}
function changepriceCezaro() {
  document.getElementById("cezaroprice").innerHTML = "R$ 49,90";
}
function changelabelCezaro() {
  document.getElementById("cezarolabel").innerHTML = "MESA | De Cezaro - 720ml";
}
function changetagCezaro() {
  document.getElementById("cezarotag").innerHTML = "10,5% ABV";
}

function changeCezaro2() {
  cezaroChange.src = "../imagens/vinho3_2.png";
}
function changetxtCezaro2() {
  document.getElementById("cezaroname").innerHTML = "Vinho Tinto Seco";
}
function changepriceCezaro2() {
  document.getElementById("cezaroprice").innerHTML = "R$ 44,90";
}
function changelabelCezaro2() {
  document.getElementById("cezarolabel").innerHTML =
    "SERRA GAÚCHA | De Cezaro - 720ml";
}
function changetagCezaro2() {
  document.getElementById("cezarotag").innerHTML = "10,5% ABV";
}

function changeCezaro3() {
  cezaroChange.src = "../imagens/vinho3_3.png";
}
function changetxtCezaro3() {
  document.getElementById("cezaroname").innerHTML = "Vinho Rosé Seco";
}
function changepriceCezaro3() {
  document.getElementById("cezaroprice").innerHTML = "R$ 48,20";
}
function changelabelCezaro3() {
  document.getElementById("cezarolabel").innerHTML = "MESA | De Cezaro - 750ml";
}
function changetagCezaro3() {
  document.getElementById("cezarotag").innerHTML = "11% ABV";
}

function changeCezaro4() {
  cezaroChange.src = "../imagens/vinho3_4.png";
}
function changetxtCezaro4() {
  document.getElementById("cezaroname").innerHTML = "Vinho Branco Suave";
}
function changepriceCezaro4() {
  document.getElementById("cezaroprice").innerHTML = "R$ 42,90";
}
function changelabelCezaro4() {
  document.getElementById("cezarolabel").innerHTML = "MESA | De Cezaro - 720ml";
}
function changetagCezaro4() {
  document.getElementById("cezarotag").innerHTML = "10,8% ABV";
}

function changeCezaro5() {
  cezaroChange.src = "../imagens/vinho3_5.png";
}
function changetxtCezaro5() {
  document.getElementById("cezaroname").innerHTML = "Vinho Branco Seco";
}
function changepriceCezaro5() {
  document.getElementById("cezaroprice").innerHTML = "R$ 44,90";
}
function changelabelCezaro5() {
  document.getElementById("cezarolabel").innerHTML = "MESA | De Cezaro - 750ml";
}
function changetagCezaro5() {
  document.getElementById("cezarotag").innerHTML = "10,8% ABV";
}

function changeCezaro6() {
  cezaroChange.src = "../imagens/vinho3_6.png";
}
function changetxtCezaro6() {
  document.getElementById("cezaroname").innerHTML = "Vinho Tinto Seco";
}
function changepriceCezaro6() {
  document.getElementById("cezaroprice").innerHTML = "R$ 48,90";
}
function changelabelCezaro6() {
  document.getElementById("cezarolabel").innerHTML = "MESA | De Cezaro - 750ml";
}
function changetagCezaro() {
  document.getElementById("cezarotag").innerHTML = "11% ABV";
}

//partridge vinho
let partChange = document.querySelector("#v5 img#partChange");
function changePart() {
  partChange.src = "../imagens/vinho5.png";
}
function changetxtPart() {
  document.getElementById("partname").innerHTML = "Vinho Tinto Seco Reserva";
}
function changepricePart() {
  document.getElementById("partprice").innerHTML = "R$ 90,99";
}
function changelabelPart() {
  document.getElementById("partlabel").innerHTML =
    "PETIT VERDOT | Partridge - 750ml";
}

function changePart2() {
  partChange.src = "../imagens/vinho5_2.png";
}
function changetxtPart2() {
  document.getElementById("partname").innerHTML = "Vinho Tinto Seco Flying";
}
function changepricePart2() {
  document.getElementById("partprice").innerHTML = "R$ 88,90";
}
function changelabelPart2() {
  document.getElementById("partlabel").innerHTML = "MALBEC | Partridge - 750ml";
}

function changePart3() {
  partChange.src = "../imagens/vinho5_3.png";
}
function changetxtPart3() {
  document.getElementById("partname").innerHTML = "Vinho Tinto Seco Flying";
}
function changepricePart3() {
  document.getElementById("partprice").innerHTML = "R$ 86,99";
}
function changelabelPart3() {
  document.getElementById("partlabel").innerHTML =
    "CABERNET | Partridge - 750ml";
}

function changePart4() {
  partChange.src = "../imagens/vinho5_4.png";
}
function changetxtPart4() {
  document.getElementById("partname").innerHTML = "Vinho Branco Unfiltered";
}
function changepricePart4() {
  document.getElementById("partprice").innerHTML = "R$ 99,90";
}
function changelabelPart4() {
  document.getElementById("partlabel").innerHTML =
    "SAUVIGNON | Partridge - 750ml";
}

//lautaro vinho
let lautaroChange = document.querySelector("#v6 img#lautaroChange");
function changeLautaro() {
  lautaroChange.src = "../imagens/vinho6.png";
}
function changetxtLautaro() {
  document.getElementById("lautaroname").innerHTML = "Vinho Tinto Suave";
}
function changepriceLautaro() {
  document.getElementById("lautaroprice").innerHTML = "R$ 76,90";
}
function changelabelLautaro() {
  document.getElementById("lautarolabel").innerHTML =
    "SAUVIGNON | Lautaro - 750ml";
}
function changetagLautaro() {
  document.getElementById("lautarotag").innerHTML = "13,5% ABV";
}

function changeLautaro2() {
  lautaroChange.src = "../imagens/vinho6_2.png";
}
function changetxtLautaro2() {
  document.getElementById("lautaroname").innerHTML = "Vinho Tinto Suave";
}
function changepriceLautaro2() {
  document.getElementById("lautaroprice").innerHTML = "R$ 84,90";
}
function changelabelLautaro2() {
  document.getElementById("lautarolabel").innerHTML =
    "CABERNET | Lautaro - 750ml";
}
function changetagLautaro2() {
  document.getElementById("lautarotag").innerHTML = "13% ABV";
}

function changeLautaro3() {
  lautaroChange.src = "../imagens/vinho6_3.png";
}
function changetxtLautaro3() {
  document.getElementById("lautaroname").innerHTML = "Vinho Tinto Seco";
}
function changepriceLautaro3() {
  document.getElementById("lautaroprice").innerHTML = "R$ 72,80";
}
function changelabelLautaro3() {
  document.getElementById("lautarolabel").innerHTML =
    "CARMÉNÈRE | Lautaro - 750ml";
}
function changetagLautaro3() {
  document.getElementById("lautarotag").innerHTML = "14% ABV";
}

//gato negro vinho
let gatoChange = document.querySelector("#v7 img#gatoChange");
function changeGato() {
  gatoChange.src = "../imagens/vinho7.png";
}
function changetxtGato() {
  document.getElementById("gatoname").innerHTML = "Vinho Tinto Seco";
}
function changepriceGato() {
  document.getElementById("gatoprice").innerHTML = "R$ 38,90";
}
function changelabelGato() {
  document.getElementById("gatolabel").innerHTML =
    "CABERNET | Gato Negro - 750ml";
}

function changeGato2() {
  gatoChange.src = "../imagens/vinho7_2.png";
}
function changetxtGato2() {
  document.getElementById("gatoname").innerHTML = "Vinho Tinto Seco";
}
function changepriceGato2() {
  document.getElementById("gatoprice").innerHTML = "R$ 46,90";
}
function changelabelGato2() {
  document.getElementById("gatolabel").innerHTML =
    "PINOT NOIR | Gato Negro - 750ml";
}

function changeGato3() {
  gatoChange.src = "../imagens/vinho7_3.png";
}
function changetxtGato3() {
  document.getElementById("gatoname").innerHTML = "Vinho Tinto Suave";
}
function changepriceGato3() {
  document.getElementById("gatoprice").innerHTML = "R$ 37,99";
}
function changelabelGato3() {
  document.getElementById("gatolabel").innerHTML =
    "PINOT NOIR | Gato Negro - 750ml";
}

function changeGato4() {
  gatoChange.src = "../imagens/vinho7_4.png";
}
function changetxtGato4() {
  document.getElementById("gatoname").innerHTML = "Vinho Tinto Seco";
}
function changepriceGato4() {
  document.getElementById("gatoprice").innerHTML = "R$ 36,18";
}
function changelabelGato4() {
  document.getElementById("gatolabel").innerHTML =
    "MERLOT | Gato Negro - 750ml";
}

function changeGato5() {
  gatoChange.src = "../imagens/vinho7_5.png";
}
function changetxtGato5() {
  document.getElementById("gatoname").innerHTML = "Vinho Tinto Seco";
}
function changepriceGato5() {
  document.getElementById("gatoprice").innerHTML = "R$ 39,70";
}
function changelabelGato5() {
  document.getElementById("gatolabel").innerHTML =
    "MALBEC | Gato Negro - 750ml";
}

//lautaro vinho
let marianiChange = document.querySelector("#v8 img#marianiChange");
function changeMariani() {
  marianiChange.src = "../imagens/vinho8.png";
}
function changetxtMariani() {
  document.getElementById("marianiname").innerHTML = "Vinho Tinto Suave";
}
function changepriceMariani() {
  document.getElementById("marianiprice").innerHTML = "R$ 32,90";
}
function changelabelMariani() {
  document.getElementById("marianilabel").innerHTML =
    "MESA | Jorge Mariani - 750ml";
}
function changetagMariani() {
  document.getElementById("marianitag").innerHTML = "10,8% ABV";
}

function changeMariani2() {
  marianiChange.src = "../imagens/vinho8_2.png";
}
function changetxtMariani2() {
  document.getElementById("marianiname").innerHTML = "Vinho Tinto Seco";
}
function changepriceMariani2() {
  document.getElementById("marianiprice").innerHTML = "R$ 34,90";
}
function changelabelMariani2() {
  document.getElementById("marianilabel").innerHTML =
    "BORDÔ | Jorge Mariani - 750ml";
}
function changetagMariani2() {
  document.getElementById("marianitag").innerHTML = "10,8% ABV";
}

function changeMariani3() {
  marianiChange.src = "../imagens/vinho8_3.png";
}
function changetxtMariani3() {
  document.getElementById("marianiname").innerHTML = "Vinho Branco Suave";
}
function changepriceMariani3() {
  document.getElementById("marianiprice").innerHTML = "R$ 32,90";
}
function changelabelMariani3() {
  document.getElementById("marianilabel").innerHTML =
    "CHARDONNAY | Jorge Mariani - 750ml";
}
function changetagMariani3() {
  document.getElementById("marianitag").innerHTML = "11% ABV";
}

function changeMariani4() {
  marianiChange.src = "../imagens/vinho8_4.png";
}
function changetxtMariani4() {
  document.getElementById("marianiname").innerHTML = "Vinho Branco Seco";
}
function changepriceMariani4() {
  document.getElementById("marianiprice").innerHTML = "R$ 32,90";
}
function changelabelMariani4() {
  document.getElementById("marianilabel").innerHTML =
    "SAUVIGNON | Jorge Mariani - 750ml";
}
function changetagMariani4() {
  document.getElementById("marianitag").innerHTML = "11% ABV";
}

function changeMariani5() {
  marianiChange.src = "../imagens/vinho8_5.png";
}
function changetxtMariani5() {
  document.getElementById("marianiname").innerHTML = "Vinho Rosé Seco";
}
function changepriceMariani5() {
  document.getElementById("marianiprice").innerHTML = "R$ 36,80";
}
function changelabelMariani5() {
  document.getElementById("marianilabel").innerHTML =
    "CABERNET | Jorge Mariani - 750ml";
}
function changetagMariani5() {
  document.getElementById("marianitag").innerHTML = "12% ABV";
}

function changeMariani6() {
  marianiChange.src = "../imagens/vinho8_6.png";
}
function changetxtMariani6() {
  document.getElementById("marianiname").innerHTML = "Vinho Tinto Seco";
}
function changepriceMariani6() {
  document.getElementById("marianiprice").innerHTML = "INDISPONÍVEL";
}
function changelabelMariani6() {
  document.getElementById("marianilabel").innerHTML =
    "ISABEL | Jorge Mariani - 750ml";
}
function changetagMariani6() {
  document.getElementById("marianitag").innerHTML = "10,8% ABV";
}

//garibaldi esp

let garibaldiChange = document.querySelector("#e1 img#garibaldiChange");
function changeGaribaldi() {
  garibaldiChange.src = "../imagens/esp1.png";
}
function changetxtGaribaldi() {
  document.getElementById("garibaldiname").innerHTML =
    "Espumante Prosecco Brut";
}
function changepriceGaribaldi() {
  document.getElementById("garibaldiprice").innerHTML = "R$ 39,90";
}
function changetagGaribaldi() {
  document.getElementById("garibalditag").innerHTML = "11% ABV";
}

function changeGaribaldi2() {
  garibaldiChange.src = "../imagens/esp1_2.png";
}
function changetxtGaribaldi2() {
  document.getElementById("garibaldiname").innerHTML =
    "Espumante Chardonnay Brut";
}
function changepriceGaribaldi2() {
  document.getElementById("garibaldiprice").innerHTML = "R$ 39,90";
}
function changetagGaribaldi2() {
  document.getElementById("garibalditag").innerHTML = "12% ABV";
}

function changeGaribaldi3() {
  garibaldiChange.src = "../imagens/esp1_3.png";
}
function changetxtGaribaldi3() {
  document.getElementById("garibaldiname").innerHTML =
    "Espumante Pinot Noir Rosé";
}
function changepriceGaribaldi3() {
  document.getElementById("garibaldiprice").innerHTML = "R$ 41,80";
}
function changetagGaribaldi3() {
  document.getElementById("garibalditag").innerHTML = "12% ABV";
}

function changeGaribaldi4() {
  garibaldiChange.src = "../imagens/esp1_4.png";
}
function changetxtGaribaldi4() {
  document.getElementById("garibaldiname").innerHTML =
    "Espumante Prosecco Rosé";
}
function changepriceGaribaldi4() {
  document.getElementById("garibaldiprice").innerHTML = "R$ 42,89";
}
function changetagGaribaldi4() {
  document.getElementById("garibalditag").innerHTML = "11,5% ABV";
}

function changeGaribaldi5() {
  garibaldiChange.src = "../imagens/esp1_5.png";
}
function changetxtGaribaldi5() {
  document.getElementById("garibaldiname").innerHTML =
    "Espumante Moscatel Rosé";
}
function changepriceGaribaldi5() {
  document.getElementById("garibaldiprice").innerHTML = "R$ 39,90";
}
function changetagGaribaldi5() {
  document.getElementById("garibalditag").innerHTML = "7,5% ABV";
}

function changeGaribaldi6() {
  garibaldiChange.src = "../imagens/esp1_6.png";
}
function changetxtGaribaldi6() {
  document.getElementById("garibaldiname").innerHTML = "Espumante Moscatel";
}
function changepriceGaribaldi6() {
  document.getElementById("garibaldiprice").innerHTML = "R$ 39,90";
}
function changetagGaribaldi6() {
  document.getElementById("garibalditag").innerHTML = "7,5% ABV";
}

//absolut

let absolutChange = document.querySelector("#vd1 img#absolutChange");
function changeAbsolut() {
  absolutChange.src = "../imagens/vodka1.png";
}
function changetxtAbsolut() {
  document.getElementById("absolutname").innerHTML = "Vodka Absolut";
}
function changepriceAbsolut() {
  document.getElementById("absolutprice").innerHTML = "R$ 109,90";
}
function changetagAbsolut() {
  document.getElementById("absoluttag").innerHTML = "40% ABV";
}

function changeAbsolut2() {
  absolutChange.src = "../imagens/vodka2.png";
}
function changetxtAbsolut2() {
  document.getElementById("absolutname").innerHTML = "Vodka Citron";
}
function changepriceAbsolut2() {
  document.getElementById("absolutprice").innerHTML = "R$ 115,90";
}
function changetagAbsolut2() {
  document.getElementById("absoluttag").innerHTML = "40% ABV";
}

function changeAbsolut3() {
  absolutChange.src = "../imagens/vodka3.png";
}
function changetxtAbsolut3() {
  document.getElementById("absolutname").innerHTML = "Vodka Lime";
}
function changepriceAbsolut3() {
  document.getElementById("absolutprice").innerHTML = "R$ 115,90";
}
function changetagAbsolut3() {
  document.getElementById("absoluttag").innerHTML = "40% ABV";
}

function changeAbsolut4() {
  absolutChange.src = "../imagens/vodka4.png";
}
function changetxtAbsolut4() {
  document.getElementById("absolutname").innerHTML = "Vodka Raspberry";
}
function changepriceAbsolut4() {
  document.getElementById("absolutprice").innerHTML = "R$ 118,70";
}
function changetagAbsolut4() {
  document.getElementById("absoluttag").innerHTML = "38% ABV";
}

function changeAbsolut5() {
  absolutChange.src = "../imagens/vodka5.png";
}
function changetxtAbsolut5() {
  document.getElementById("absolutname").innerHTML = "Vodka Peach";
}
function changepriceAbsolut5() {
  document.getElementById("absolutprice").innerHTML = "R$ 116,99";
}
function changetagAbsolut5() {
  document.getElementById("absoluttag").innerHTML = "38% ABV";
}

function changeAbsolut6() {
  absolutChange.src = "../imagens/vodka6.png";
}
function changetxtAbsolut6() {
  document.getElementById("absolutname").innerHTML = "Vodka Vanilia";
}
function changepriceAbsolut6() {
  document.getElementById("absolutprice").innerHTML = "R$ 120,90";
}
function changetagAbsolut6() {
  document.getElementById("absoluttag").innerHTML = "38% ABV";
}

function changeAbsolut7() {
  absolutChange.src = "../imagens/vodka7.png";
}
function changetxtAbsolut7() {
  document.getElementById("absolutname").innerHTML = "Vodka Watermelon";
}
function changepriceAbsolut7() {
  document.getElementById("absolutprice").innerHTML = "R$ 118,90";
}
function changetagAbsolut7() {
  document.getElementById("absoluttag").innerHTML = "38% ABV";
}

//jack daniels

let jackChange = document.querySelector("#w1 img#jackChange");
function changeJack() {
  jackChange.src = "../imagens/jack1.png";
}
function changetxtJack() {
  document.getElementById("jackname").innerHTML = "Whiskey Jack Daniel's";
}
function changepriceJack() {
  document.getElementById("jackprice").innerHTML = "R$ 129,90";
}
function changetagJack() {
  document.getElementById("jacktag").innerHTML = "40% ABV";
}

function changeJack2() {
  jackChange.src = "../imagens/jack2.png";
}
function changetxtJack2() {
  document.getElementById("jackname").innerHTML = "Whiskey Jack Daniel's Fire";
}
function changepriceJack2() {
  document.getElementById("jackprice").innerHTML = "R$ 135,90";
}
function changetagJack2() {
  document.getElementById("jacktag").innerHTML = "38% ABV";
}

function changeJack3() {
  jackChange.src = "../imagens/jack3.png";
}
function changetxtJack3() {
  document.getElementById("jackname").innerHTML = "Whiskey Jack Daniel's Apple";
}
function changepriceJack3() {
  document.getElementById("jackprice").innerHTML = "R$ 135,90";
}
function changetagJack3() {
  document.getElementById("jacktag").innerHTML = "38% ABV";
}

function changeJack4() {
  jackChange.src = "../imagens/jack4.png";
}
function changetxtJack4() {
  document.getElementById("jackname").innerHTML = "Whiskey Jack Daniel's Honey";
}
function changepriceJack4() {
  document.getElementById("jackprice").innerHTML = "R$ 131,90";
}
function changetagJack4() {
  document.getElementById("jacktag").innerHTML = "38% ABV";
}

//tanqueray

let tanqChange = document.querySelector("#g1 img#tanqChange");
function changeTanq() {
  tanqChange.src = "../imagens/gin4.png";
}
function changetxtTanq() {
  document.getElementById("tanqname").innerHTML = "London Dry Gin";
}
function changepriceTanq() {
  document.getElementById("tanqprice").innerHTML = "R$ 189,90";
}
function changetagTanq() {
  document.getElementById("tanqtag").innerHTML = "47,3% ABV";
}
function changelabelTanq() {
  document.getElementById("tanqlabel").innerHTML = "Tanqueray - 750ml";
}

function changeTanq2() {
  tanqChange.src = "../imagens/gin5.png";
}
function changetxtTanq2() {
  document.getElementById("tanqname").innerHTML = "Gin Rangpur";
}
function changepriceTanq2() {
  document.getElementById("tanqprice").innerHTML = "R$ 139,90";
}
function changetagTanq2() {
  document.getElementById("tanqtag").innerHTML = "41,3% ABV";
}
function changelabelTanq2() {
  document.getElementById("tanqlabel").innerHTML = "Tanqueray - 700ml";
}

function changeTanq3() {
  tanqChange.src = "../imagens/gin6.png";
}
function changetxtTanq3() {
  document.getElementById("tanqname").innerHTML = "Gin Royale";
}
function changepriceTanq3() {
  document.getElementById("tanqprice").innerHTML = "R$ 149,90";
}
function changetagTanq3() {
  document.getElementById("tanqtag").innerHTML = "41,3% ABV";
}
function changelabelTanq3() {
  document.getElementById("tanqlabel").innerHTML = "Tanqueray - 700ml";
}

function changeTanq4() {
  tanqChange.src = "../imagens/gin7.png";
}
function changetxtTanq4() {
  document.getElementById("tanqname").innerHTML = "Gin Sevilla";
}
function changepriceTanq4() {
  document.getElementById("tanqprice").innerHTML = "R$ 149,90";
}
function changetagTanq4() {
  document.getElementById("tanqtag").innerHTML = "41,3% ABV";
}
function changelabelTanq4() {
  document.getElementById("tanqlabel").innerHTML = "Tanqueray - 700ml";
}

//heineken

let heinekenChange = document.querySelector("#c1 img#heinekenChange");
function changeHeineken() {
  heinekenChange.src = "../imagens/heineken1.png";
}
function changetxtHeineken() {
  document.getElementById("heinekenname").innerHTML = "Cerveja Puro Malte";
}
function changepriceHeineken() {
  document.getElementById("heinekenprice").innerHTML = "R$ 8,90";
}
function changetagHeineken() {
  document.getElementById("heinekentag").innerHTML = "5% ABV";
}
function changelabelHeineken() {
  document.getElementById("heinekenlabel").innerHTML =
    "Heineken - Garrafa 600ml";
}

function changeHeineken2() {
  heinekenChange.src = "../imagens/heineken2.png";
}
function changetxtHeineken2() {
  document.getElementById("heinekenname").innerHTML = "Cerveja Puro Malte";
}
function changepriceHeineken2() {
  document.getElementById("heinekenprice").innerHTML = "R$ 4,90";
}
function changetagHeineken2() {
  document.getElementById("heinekentag").innerHTML = "5% ABV";
}
function changelabelHeineken2() {
  document.getElementById("heinekenlabel").innerHTML =
    "Heineken - Long Neck 330ml";
}

function changeHeineken3() {
  heinekenChange.src = "../imagens/heineken5.png";
}
function changetxtHeineken3() {
  document.getElementById("heinekenname").innerHTML = "Cerveja Puro Malte Zero";
}
function changepriceHeineken3() {
  document.getElementById("heinekenprice").innerHTML = "R$ 4,99";
}
function changetagHeineken3() {
  document.getElementById("heinekentag").innerHTML = "ZERO";
}
function changelabelHeineken3() {
  document.getElementById("heinekenlabel").innerHTML =
    "Heineken - Long Neck 330ml";
}

function changeHeineken4() {
  heinekenChange.src = "../imagens/heineken3.png";
}
function changetxtHeineken4() {
  document.getElementById("heinekenname").innerHTML = "Cerveja Puro Malte";
}
function changepriceHeineken4() {
  document.getElementById("heinekenprice").innerHTML = "R$ 5,90";
}
function changetagHeineken4() {
  document.getElementById("heinekentag").innerHTML = "4,6% ABV";
}
function changelabelHeineken4() {
  document.getElementById("heinekenlabel").innerHTML = "Heineken - Latão 470ml";
}

function changeHeineken5() {
  heinekenChange.src = "../imagens/heineken4.png";
}
function changetxtHeineken5() {
  document.getElementById("heinekenname").innerHTML = "Cerveja Puro Malte";
}
function changepriceHeineken5() {
  document.getElementById("heinekenprice").innerHTML = "R$ 3,29";
}
function changetagHeineken5() {
  document.getElementById("heinekentag").innerHTML = "4,6% ABV";
}
function changelabelHeineken5() {
  document.getElementById("heinekenlabel").innerHTML = "Heineken - Lata 269ml";
}
