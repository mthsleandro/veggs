var loader = document.getElementById("preloader");
window.addEventListener("load", function () {
  loader.style.display = "none";
});

//toggle cart radio
var toggle = document.getElementById("cartToggle");

function toggleCartClosed() {
  var radioButton = document.getElementById("cartToggle");
  radioButton.checked = false;
  toggle.innerHTML = "unchecked";
}

//remove cart item
function removeCartItem(event) {
  var buttonClicked = event.target;
  buttonClicked.parentElement.parentElement.remove();
  updateCartTotal();
}

var removeBtn = document.getElementsByClassName("cartRemove");
for (var i = 0; i < removeBtn.length; i++) {
  var cartRemoveButton = removeBtn[i];
  cartRemoveButton.addEventListener("click", removeCartItem);
}

//add to cart
var addToCart = document.getElementsByClassName("cart");
for (var i = 0; i < addToCart.length; i++) {
  var cartButton = addToCart[i];
  cartButton.addEventListener("click", addToCartButton);
}

//quantity reset
function quantityChanged(event) {
  var input = event.target;
  if (isNaN(input.value) || input.value <= 0) {
    input.value = 1;
  }
  updateCartTotal();
}

//cart total update
function updateCartTotal() {
  var cartDetails = document.getElementsByClassName("cartDetails")[0];
  var cartProd = cartDetails.getElementsByClassName("cartProd");
  var shipping = document.getElementsByClassName("shipprice");
  var total = 0;
  for (var i = 0; i < cartProd.length; i++) {
    var cartProduto = cartProd[i];
    var cartPrice = cartProduto.getElementsByClassName("cartPrice")[0];
    var cartQtd = cartProduto.getElementsByClassName("qtdInput")[0];
    var price = parseFloat(cartPrice.innerText.replace("R$", ""));
    var quantity = cartQtd.value;
    total = total + price * quantity;
  }
  total = Math.round(total * 100) / 100;
  document.getElementsByClassName("subtotalprice").innerText = "R$ " + total;
  document.getElementsByClassName("totalprice").innerText =
    "R$ " + total + shipping;
}

//get information for adding to cart
function addToCartButton(event) {
  var cartButton = event.target;
  var item = cartButton.parentElement.parentElement;
  var name = item.getElementsByTagName("h2")[0].innerText;
  var details = item.getElementsByTagName("p")[0].src;
  var price = item.getElementsByTagName("h1").innerText;
  var image = item.getElementsByTagName("img")[0].src;
  addItem(name, details, price, image);
  updateCartTotal();
}

// function addItem(name, details, price, image){
//   var cartProd = document.createElement('div');
//   cartProd.classList.add('cartGrid');
//   var cartProdNames = cartProd.getElementsByTag('h2')
//   for (var i = 0; i < cartProd.length; i++){
//     if (cartProdNames[i].innerText == name){
//       alert('Item já adicionado.')
//       return;
//     }
//   }
//   var cartItem = document.getElementsByClassName(cartProd)[0];
//   var cartProdAdd = '<div class="cartProd">
//         <div class="cartGrid cartRemove">
//         <i class="fas fa-trash-alt"></i>
//         </div>
//         <div class="cartGrid cartImage">
//           <img src="$(image)">
//         </div>
//         <div class="cartGrid cartName">
//           $('name')<br>
//           <p>$('details')</p>
//         <div class="cartGrid cartQtd">
//           <input type="number" value="1" min="1" class="qtdInput">
//         </div>
//       </div>
//       <div class="cartGrid cartPrice">$('price')</div>
//       </div>'
//   cartProd.innerHTML = cartProdAdd;
//   cartItem.append(cartProd);
//   cartProd.getElementsByClassName('cartRemove')[0].addEventListener('click', removeCartItem)
//   cartProd.getElementsByClassName('qtdInput')[0].addEventListener('change', quantityChanged)
// }

//body animation cancel
setTimeout(function () {
  document.body.className = "";
}, 200);

//show food filters
function showFoodFilter() {
  document.getElementById("foodFilter").style.display = "flex";
  document.getElementById("drinkFilter").style.display = "none";
}

//show drink filters
function showDrinkFilter() {
  document.getElementById("drinkFilter").style.display = "flex";
  document.getElementById("foodFilter").style.display = "none";
}

//hide filters on all
function hideFilters() {
  document.getElementById("foodFilter").style.display = "none";
  document.getElementById("drinkFilter").style.display = "none";
}

//filter
filterProducts("all");

function filterProducts(c) {
  var x, i;
  x = document.getElementsByClassName("produto");
  if (c == "all") c = " ";
  for (i = 0; i < x.length; i++) {
    removeClass(x[i], "show");
    if (x[i].className.indexOf(c) > -1) addClass(x[i], "show");
  }
}

function addClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    if (arr1.indexOf(arr2[i]) == -1) {
      element.className += " " + arr2[i];
    }
  }
}

function removeClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    while (arr1.indexOf(arr2[i]) > -1) {
      arr1.splice(arr1.indexOf(arr2[i]), 1);
    }
  }
  element.className = arr1.join(" ");
}

//search products
function searchBar() {
  var input, filter, ul, li, i, txtValue, txtValue2;
  input = document.getElementById("searchBar");
  filter = input.value.toUpperCase();
  ul = document.getElementById("allProd");
  li = ul.getElementsByClassName("produto");

  for (i = 0; i < li.length; i++) {
    h2 = li[i].getElementsByTagName("h2")[0];
    h3 = li[i].getElementsByTagName("h3")[0];
    txtValue = h2.textContent || h2.innerText;
    txtValue2 = h3.textContent || h3.innerText;

    if (
      txtValue.toUpperCase().indexOf(filter) > -1 ||
      txtValue2.toUpperCase().indexOf(filter) > -1
    ) {
      li[i].style.display = "";
    } else {
      li[i].style.display = "none";
    }
  }
}

function clearInput() {
  var getValue = document.getElementById("searchBar");
  getValue.value = "";
  searchBar();
}

//search alcohol
function searchBarAlcohol() {
  var input, filter, ul, li, i, txtValue, txtValue2;
  input = document.getElementById("searchBar2");
  filter = input.value.toUpperCase();
  ul = document.getElementById("allAlcohol");
  li = ul.getElementsByClassName("produto");

  for (i = 0; i < li.length; i++) {
    h2 = li[i].getElementsByTagName("h2")[0];
    h3 = li[i].getElementsByTagName("h3")[0];
    txtValue = h2.textContent || h2.innerText;
    txtValue2 = h3.textContent || h3.innerText;

    if (
      txtValue.toUpperCase().indexOf(filter) > -1 ||
      txtValue2.toUpperCase().indexOf(filter) > -1
    ) {
      li[i].style.display = "";
    } else {
      li[i].style.display = "none";
    }
  }
}

function clearInput() {
  var getValue = document.getElementById("searchBar2");
  getValue.value = "";
  searchBarAlcohol();
}

//color active
const COLOR_BTNS = document.querySelectorAll(".color");
COLOR_BTNS.forEach((color) => {
  color.addEventListener("click", () => {
    let colorNameClass = color.className;
    if (!color.classList.contains("activeColor")) {
      let colorName = colorNameClass.slice(
        colorNameClass.indexOf("-") + 1,
        colorNameClass.length
      );
      resetActivBtns();
      color.classList.add("activeColor");
      setNewColor(colorName);
    }
  });
});

function resetActivBtns() {
  COLOR_BTNS.forEach((color) => {
    color.classList.remove("activeColor");
  });
}

//slideshow
slideshow();
nextImage();

function slideshow() {
  let count = 1;
  document.getElementById("radio1").checked = true;

  setInterval(function () {
    nextImage();
  }, 6000);

  function nextImage() {
    count++;
    if (count > 4) {
      count = 1;
    }
    document.getElementById("radio" + count).checked = true;
  }
}
